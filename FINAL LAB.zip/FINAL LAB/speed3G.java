public class speed3G implements speed{
    @Override
    public String getKecepatan(){
        return "kecepatan jaringan 3G yaitu 21.6";
    }
}