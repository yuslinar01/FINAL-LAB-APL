Nama        : Nurul Izzati
NPM         : 1908107010067
Matakuliah  : Arsitektur Perangkat Lunak

Keterangan Tugas :
Pattern : Strategy Pattern dan Adapter Pattern
Studi Kasus : Network
Keterangan : 
	Pada studi kasus saya membuat sebuah program dimana program tersebut akan meminta user untuk memilih salah satu hal yang ingin user ketahui, yang mana terdapat 2 pilihan yaitu Network Types dan Network Adapter. Apabila user memilih network types makan user kembali diminta untuk memilih salah satu jenis jaringan yang user ingin ketahui, disini terdapat 3 jenis yaitu LAN, PAN, dan MAN. Setelah dipilih maka program akan menampilkan penjelasan dari jenis yang dipilih. Apabila user memilih network Adapetr maka akan ditampilkan jenis jaringan 3G dan 4G yang diubah ke Mbps

	Penggunaan strategy pattern nya yaitu pada saat pemilihan jenis jaringan. Sedangkan penggunaan adapter pattern nya adalah pada saat mengubah 3G dan 4G menjadi Mbps.
