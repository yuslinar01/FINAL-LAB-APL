public interface speed{
    public String getKecepatan();
}