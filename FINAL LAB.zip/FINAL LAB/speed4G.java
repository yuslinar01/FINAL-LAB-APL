public class speed4G implements speed{
    @Override
    public String getKecepatan(){
        return "kecepatan jaringan 4G yaitu 100";
    }
}